#!/usr/bin/env python3
"""
validate_policy.py

Skrip sederhana untuk mendeteksi red flag umum pada dokumen kebijakan
IAM bergaya AWS (format JSON): wildcard Action, wildcard Resource, dan
ketiadaan blok Condition.

Cara pakai:
    python3 validate_policy.py <nama_file.json>

Skrip ini murni membaca dan menganalisis teks JSON secara statis.
Tidak ada koneksi ke cloud sungguhan, tidak perlu kredensial apa pun.
"""

import json
import sys


def muat_kebijakan(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def daftar_statement(kebijakan):
    stmt = kebijakan.get("Statement", [])
    if isinstance(stmt, dict):
        return [stmt]
    return stmt


def cek_wildcard_action(statement):
    action = statement.get("Action", [])
    if isinstance(action, str):
        action = [action]
    return "*" in action


def cek_wildcard_resource(statement):
    resource = statement.get("Resource", [])
    if isinstance(resource, str):
        resource = [resource]
    return "*" in resource


def cek_tanpa_condition(statement):
    return "Condition" not in statement


def evaluasi(path):
    kebijakan = muat_kebijakan(path)
    statements = daftar_statement(kebijakan)

    print(f"\n=== Hasil audit: {path} ===")
    total_red_flag = 0

    for idx, stmt in enumerate(statements, start=1):
        sid = stmt.get("Sid", f"Statement #{idx}")
        print(f"\nStatement: {sid}")

        temuan = []
        if stmt.get("Effect") != "Allow":
            print("  (Effect bukan Allow, dilewati dari pengecekan red flag)")
            continue

        if cek_wildcard_action(stmt):
            temuan.append("Wildcard Action (\"*\") -> mengizinkan SEMUA operasi")
        if cek_wildcard_resource(stmt):
            temuan.append("Wildcard Resource (\"*\") -> akses ke SEMUA resource")
        if cek_tanpa_condition(stmt):
            temuan.append("Tidak ada blok Condition -> berlaku tanpa batasan waktu/lokasi")

        if temuan:
            for t in temuan:
                print(f"  [RED FLAG] {t}")
            total_red_flag += len(temuan)
        else:
            print("  Tidak ditemukan red flag pada statement ini.")

    print(f"\nTotal red flag ditemukan pada {path}: {total_red_flag}")
    return total_red_flag


def main():
    if len(sys.argv) != 2:
        print("Cara pakai: python3 validate_policy.py <nama_file.json>")
        sys.exit(1)

    path = sys.argv[1]
    try:
        total = evaluasi(path)
    except FileNotFoundError:
        print(f"File tidak ditemukan: {path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"File bukan JSON yang valid: {e}")
        sys.exit(1)

    # exit code tidak nol jika masih ada red flag, supaya bisa dipakai
    # sebagai gate otomatis kalau suatu saat diperlukan
    sys.exit(1 if total > 0 else 0)


if __name__ == "__main__":
    main()
